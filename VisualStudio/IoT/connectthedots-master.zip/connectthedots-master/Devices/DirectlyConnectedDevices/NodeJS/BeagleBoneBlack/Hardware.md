# Hardware requirements for BeagleBone Black & Grove sensors #

 - [BeagleBone Black][1]

##Supported Sensors

- [Seeed Grove Cape for BeagleBone series ][2]
- [Seeed Grove Light Sensor ][3]
- [Seeed Grove temperature sensor ][4]

  [1]: http://beagleboard.org/black
  [2]: http://www.seeedstudio.com/depot/Grove-Cape-for-BeagleBone-Series-p-1718.html
  [3]: http://www.seeedstudio.com/depot/Grove-Light-Sensor-p-746.html
  [4]: http://www.seeedstudio.com/depot/Grove-Temperature-Sensor-p-774.html
  
  
 
