# Hardware requirements for Intel Edison + Seeed Xadow wearable kit #

 - [Intel Edison kit for Arduino][1]

##Supported Sensors

- [Seeed Xadow wearable kit for Intel Edison][2]

  [1]: http://www.intel.com/buy/us/en/product/emergingtechnologies/intel-edison-kit-462187
  [2]: http://www.seeedstudio.com/depot/Xadow-Wearable-Kit-For-Intel-Edison-p-2428.html
 
