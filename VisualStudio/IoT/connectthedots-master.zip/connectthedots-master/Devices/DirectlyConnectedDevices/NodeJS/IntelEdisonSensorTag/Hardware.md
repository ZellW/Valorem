# Hardware requirements for Intel Edison + TI SensorTag project #

 - [Intel Edison with the board for Arduino][1]

##Supported Sensors

- [TI SensorTag][2] (tested only with CC2541. Should work with newer version CC2650)

  [1]: http://www.intel.com/content/www/us/en/do-it-yourself/edison.html
  [2]: http://www.ti.com/sensortag
 
