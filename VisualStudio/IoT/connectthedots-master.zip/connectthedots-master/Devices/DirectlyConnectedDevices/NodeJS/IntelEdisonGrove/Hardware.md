# Hardware requirements for Intel Edison + Seeed Xadow wearable kit #

 - [Intel Edison kit for Arduino][1]

##Supported Sensors

- [Seeed Grove starter kit for Intel IoT][2]
- and [Seeed Grove Environment Kit for Intel Edison][3]

  [1]: http://www.intel.com/buy/us/en/product/emergingtechnologies/intel-edison-kit-462187
  [2]: http://www.seeedstudio.com/depot/Grove-starter-kit-plus-Intel-IoT-Edition-for-Intel-Galileo-Gen-2-and-Edison-p-1978.html?cPath=84_13
  [3]: http://www.seeedstudio.com/depot/Grove-Indoor-Environment-Kit-for-Intel-Edison-p-2427.html
