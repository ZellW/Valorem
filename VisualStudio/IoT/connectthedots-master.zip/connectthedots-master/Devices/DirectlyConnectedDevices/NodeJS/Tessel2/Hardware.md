# Hardware requirements for Tessel 2 and modules #

 - [Tessel 2][1]

## Supported Sensors ##

- [Tessel 2 Ambient Module][2]


  [1]: https://tessel.io/
  [2]: https://tessel.io/modules#module-ambient
