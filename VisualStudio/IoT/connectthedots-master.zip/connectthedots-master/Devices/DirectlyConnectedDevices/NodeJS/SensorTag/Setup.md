### Generic SensorTag connection using a Raspberry PI, Linux, Mac OS and other Unix/Linux.

### Raspberry Pi requirements
You will need Bluez, you can follow [this](http://www.elinux.org/RPi_Bluetooth_LE) tutorial to achieve it.

Set up settings.json as with any other and you are ready to go
```
sudo npm start
```
