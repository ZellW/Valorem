To set up a Raspberry Pi as a simple gateway for connecting Arduino or other sensors to Azure you will need to procure:

1. [Raspberry Pi B/B+](http://www.raspberrypi.org/products/model-b-plus/)
2. Power supply
3. Case (optional)

**Note**: Only the model above has been tested. 